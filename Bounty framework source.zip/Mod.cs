﻿using HarmonyLib;
using Verse;

namespace BountiesMod
{
    public class ModMain : Mod
    {
        public ModMain(ModContentPack content) : base(content)
        {
            Harmony harmony = new Harmony("MetaVandetta.BountiesMod");
            harmony.PatchAll();
        }
    }
}