﻿using RimWorld;
using RimWorld.Planet;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using Verse;

namespace BountiesMod
{
    public class WorldObjectComp_Bounties : WorldObjectComp
    {
        public override IEnumerable<Gizmo> GetCaravanGizmos(Caravan caravan)
        {
            if (parent.Faction == null)
                yield break;

            BountiesModExtension modExtension = parent.Faction.def.GetModExtension<BountiesModExtension>();

            if (modExtension == null || !modExtension.offersBounties)
                yield break;

            Command_Action bountiesCommand = new Command_Action
            {
                defaultLabel = "META_ViewBounties".Translate(),
                defaultDesc = "META_BrowseBounties".Translate(parent.Faction.Name),
                icon = ContentFinder<Texture2D>.Get("UI/META_FulfillBounty"),
                action = () =>
                {
                    Find.WindowStack.Add(new Dialog_Bounty_Caravan(parent.Faction, caravan.RandomOwner(), caravan));
                }
            };

            yield return bountiesCommand;

        }
    }

    public class WorldObjectCompProperties_Bounties : WorldObjectCompProperties
    {
        public WorldObjectCompProperties_Bounties()
        {
            compClass = typeof(WorldObjectComp_Bounties);
        }
    }
}