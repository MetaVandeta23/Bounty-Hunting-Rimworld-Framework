﻿using RimWorld;
using System.Collections.Generic;
using Verse;

namespace BountiesMod
{
    public class GameComponent_Bounties : GameComponent
    {
        public int tickCounter = 0;
        public int ticksPerBountyRefresh = 3 * 60000;
        public Dictionary<string, List<BountyDef>> factionBounties = new Dictionary<string, List<BountyDef>>();

        // this is where the actual handling of bounties happens
        // on a new game, and on a three day interval, we regenerate bounties for all factions which offer bounties
        // they're all also stored here since faction instances are pretty limited
        public GameComponent_Bounties(Game game)
        {}

        public override void StartedNewGame()
        {
            GenerateBounties();
        }

        public override void GameComponentTick()
        {
            tickCounter++;
            if (tickCounter >= ticksPerBountyRefresh)
            {
                tickCounter = 0;
                GenerateBounties();
            }
        }

        public void GenerateBounties()
        {
            factionBounties.Clear();
            foreach (Faction faction in Find.FactionManager.AllFactionsListForReading)
            {
                BountiesModExtension modExtension = faction.def.GetModExtension<BountiesModExtension>();
                if (modExtension != null && modExtension.offersBounties)
                {
                    List<BountyDef> bountyList = new List<BountyDef>
                    {
                        DefDatabase<BountyDef>.AllDefsListForReading.RandomElement(),
                        DefDatabase<BountyDef>.AllDefsListForReading.RandomElement(),
                        DefDatabase<BountyDef>.AllDefsListForReading.RandomElement()
                    };
                    factionBounties[faction.def.defName] = bountyList;
                }
            }
        }

        public List<BountyDef> GetBountiesForFaction(Faction faction)
        {
            if (factionBounties.TryGetValue(faction.def.defName, out List<BountyDef> list))
            {
                return list;
            }
            return null;
        }

        public override void ExposeData()
        {
            Scribe_Values.Look(ref tickCounter, "tickCounter", 0);
            Scribe_Collections.Look(ref factionBounties, "factionBounties", LookMode.Value, LookMode.Def);
        }
    }
}